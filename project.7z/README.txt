README.txt

Logic of my program:
First, my code takes input from the command line:
1. Using argparse and arguments -g, -n, -r, —e, and -o, my code takes in the gender, phone number, reason, ending, and output name
2. next, it validates each input. If all of the inputs are valid, it pulls the proper mp3’s from the website and combines them into a single mp3 file. 
3. If the user does not give valid input, the manual input section begins. 
4. The code goes through each argument and asks the user for input. Then the user has to validate the inputs before the code compiles them into an mp3

*notes
- I did not include the m-leave_a_message.mp3 or m-youre_welcome.mp3 mp3’s in my code because in the sample input, they were not marked with a beginning, reason, or end so I left them to be, hope this doesn’t mess up the file size. 
- I think that the code Chi showed us in class to combine mp3’s works on both mac and windows. I couldn’t find anything stating otherwise, but again hope this doesn’t screw up the bot lol 