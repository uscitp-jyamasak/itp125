#put inmport statements at top of file
import urllib2 #fetches URLs (mp3s)
import argparse #allow command line input
import platform #check the OS of the user

# this will ask for male or female voice
def ask_gender():

    gender = ""

    #ask the user what gender they would like until they enter m,f,male,or female
    while gender.lower() not in ['m', 'f', 'male', 'female']:
        gender = raw_input("What gender would you like: ")

    #return the gender
    return gender.lower()

#will ask for the phone number to verbalize
def ask_phone():

    phone = ""
    clean_phone = ""

    #ask the user for a phone number until there are 10 digits in clean_phone
    while len(clean_phone) != 10:
        phone = raw_input("What is your phone number: ")

        #for each character in the input phone number, append each digit to clean_phone
        for character in phone:
            if character.isdigit():
                clean_phone += character

        #if there are not 10 digits in clean_phone then run the loop again
        if len(clean_phone) != 10:
            clean_phone = ""

    return clean_phone

#depending on male/female print out and get reasons from them
def ask_reason(gender):

    reason = ""
  #figure out male/female
    if gender in ['f', 'female']:

        while reason not in ['1','2','3','4','5']:
            print("Please select your reason...")
            print ("1. Ingesting Old Spice")
            print ("2. Listening to reading")
            print ("3. Lobster dinner")
            print ("4. Moon Kiss")
            print ("5. Riding a horse")

            reason = raw_input("Please make your selection: ")
    else:
        while reason not in ['1','2','3','4']:
            print("Please select your reason...")
            print ("1. Building")
            print ("2. Cracking Walnuts")
            print ("3. Polishing Monocle")
            print ("4. Ripping weights")

            reason = raw_input("Please make your selection: ")

    return reason

#depending on male/female get the ending they want
def ask_ending(gender):

    ending = ""
    if gender in ['f', 'female']:
        while ending not in ['1','2']:
            print("Please select your ending...")
            print ("1. She will get back to you")
            print ("2. Thanks for calling")
            ending = raw_input("Please choose an ending:")
    else:
        while ending not in ['1','2','3','4','5']:
            print("Please select your ending...")
            print ("1. Horse")
            print ("2. Jingle")
            print ("3. On Phone")
            print ("4. Swan Dive")
            print ("5. Voicemail")
            ending = raw_input("Please choose an ending:")
    return ending
#asks for the output name
def ask_output():
    output = raw_input("What would you like to name the output file?")
    return output
#check if the gender is good
def validate_gender(gender):
    if gender in ['m','male','f','female']:
        return gender
    else:
        return -1 #check this
#check if phone number is valid
def validate_phone(phone):
    #clean the input for phone
    clean_phone = ""
    for character in phone:
        if character.isdigit():
            clean_phone += character
    if len(clean_phone) == 10:
        return clean_phone
    else:
        return -1 #check this

#validate the reason number
def validate_reason (reason, gender):
    if gender in ['f', 'female']:
        if reason in ['1','2','3','4','5']:
            return reason
        else:
            return -1

    if gender in ['m', 'male']:
        if reason in ['1','2','3','4']:
            return reason
        else:
            return -1
#validate the ending
def validate_ending(ending,gender):
    if ending in ['f','female']:
        if ending in ['1','2']:
            return ending
        else:
            return -1
    else:
        if ending in ['1','2','3','4','5']:
            return ending
        else:
            return -1

#develops the mp3 clip
def get_mp3(gender,phone,reason,ending,output):

    server = "http://www-bcf.usc.edu/~chiso/itp125/project_version_1/"

    #open file to open in binary mode
    final_mp3 = open(output +".mp3", "wb")



    if gender in ['m','male']:
        #implement pulling data for male
        #beginning
        final_mp3.write(urllib2.urlopen(server + "m-b1-hello.mp3").read())
        final_mp3.write(urllib2.urlopen(server + "m-b2-have_dialed.mp3").read())

        for digit in phone:

            final_mp3.write(urllib2.urlopen(server + digit + ".mp3").read())

        final_mp3.write(urllib2.urlopen(server + "m-r0-cannot_come_to_phone.mp3").read())
        #for each reason pull data

        if reason == "1":
            final_mp3.write(urllib2.urlopen(server + "m-r1-building.mp3").read())
        elif reason == "2":
            final_mp3.write(urllib2.urlopen(server + 'm-r2-cracking_walnuts.mp3').read())
        elif reason == "3":
            final_mp3.write(urllib2.urlopen(server + 'm-r3-polishing_monocole.mp3').read())
        elif reason == "4":
            final_mp3.write(urllib2.urlopen(server + 'm-r4-ripping_weights.mp3').read())

        #implement code for the endings
        if ending == "1":
            final_mp3.write(urllib2.urlopen(server + 'm-e1-horse.mp3').read())
        elif ending == "2":
            final_mp3.write(urllib2.urlopen(server + 'm-e2-jingle.mp3').read())
        elif ending == "3":
            final_mp3.write(urllib2.urlopen(server + 'm-e3-on_phone.mp3').read())
        elif ending == "4":
            final_mp3.write(urllib2.urlopen(server + 'm-e4-swan_dive.mp3').read())
        elif ending == "5":
            final_mp3.write(urllib2.urlopen(server + 'm-e5-voicemail.mp3').read())

    else:
    #if gender in ['f','female']:
        #implement pulling data for female

        #beginning
        final_mp3.write(urllib2.urlopen(server + "f-b1-hello_caller.mp3").read())
        final_mp3.write(urllib2.urlopen(server + "f-b2-lady_at.mp3").read())

        for digit in phone:

            final_mp3.write(urllib2.urlopen(server + digit + ".mp3").read())

        #reasons
        final_mp3.write(urllib2.urlopen(server + "f-r0.1-unable_to_take_call.mp3").read())
        final_mp3.write(urllib2.urlopen(server + "f-r0.2-she_is_busy.mp3").read())
        if reason == "1":
            final_mp3.write(urllib2.urlopen(server + 'f-r1-ingesting_old_spice.mp3').read())
        elif reason == "2":
            final_mp3.write(urllib2.urlopen(server + 'f-r2-listening_to_reading.mp3').read())
        elif reason == "3":
            final_mp3.write(urllib2.urlopen(server + 'f-r3-lobster_dinner.mp3').read())
        elif reason == "4":
            final_mp3.write(urllib2.urlopen(server + 'f-r4-moon_kiss.mp3').read())
        elif reason == "5":
            final_mp3.write(urllib2.urlopen(server + 'f-r5-riding_a_horse.mp3').read())

        #implement code for female ending
        if ending == "1":
            final_mp3.write(urllib2.urlopen(server + 'f-e1-she_will_get_back_to_you.mp3').read())
        elif reason == "2":
            final_mp3.write(urllib2.urlopen(server + 'f-e2-thanks_for_calling.mp3').read())

    #always close your files
    final_mp3.close()

#this is where the program will start
if __name__ == "__main__":

    #this allows input from the command line
    parser = argparse.ArgumentParser(description = "whooooo I <3 python")

    parser.add_argument('-g') #gender
    parser.add_argument('-n') #phone number
    parser.add_argument('-r') #reasons
    parser.add_argument('-e') #endings
    parser.add_argument('-o') #output name

    args = parser.parse_args()

    manual = "n"
    while True:
    #check if the gender is in boundaries
        if validate_gender (args.g) == -1:
            print ("Invalid gender")
            manual = "y"
            break
        #validate phone number
        if validate_phone (args.n) == -1:
            print ("Invalid Phone Number")
            manual = "y"
            break
        #check if the reason number is in bounds
        if validate_reason(args.r,args.g) == -1:
            print ("You did not choose a valid reason :(")
            manual = "y"
            break
        #check if the endings are in bounds
        if validate_ending (args.e, args.g) == -1:
            print ("You did not choose a valid ending")
            manual = "y"
            break
        get_mp3(args.g,args.n,args.r, args.e, args.o)
        quit()
    while True:
        if manual == "y":
            args.g = ask_gender()
            args.n = ask_phone()
            args.r = ask_reason(args.g)
            args.e = ask_ending(args.g)
            args.o = ask_output()
            if validate_gender (args.g) == -1:
                print ("Invalid gender")
                continue
            #validate phone number
            if validate_phone (args.n) == -1:
                print ("Invalid Phone Number")
                continue
            #check if the reason number is in bounds
            if validate_reason(args.r,args.g) == -1:
                print ("You did not choose a valid reason :(")
                continue
            #check if the endings are in bounds
            if validate_ending (args.e, args.g) == -1:
                print ("You did not choose a valid ending")
                continue
            print "Gender:" + args.g
            print "Number:" + args.n
            print "Reason:" + args.r
            print "Ending:" + args.e
            print "Output:" + args.o
            answer = raw_input("Is this information correct(y/n)?")
            if answer == "n":
                continue
            get_mp3(args.g,args.n,args.r, args.e, args.o)
            quit()




#argparse
