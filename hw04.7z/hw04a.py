fruits = {'a': 'bananas','b': 'grapefruit'}
for item in fruits:
    print fruits[item]
else:
    print 'done!'
