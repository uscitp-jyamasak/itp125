with open("text.txt", "r+") as my_file:
    my_file.write("hello")
if my_file.closed != True:
    my_file.close()
print my_file.closed
